import mysql.connector
mydb = mysql.connector.connect(host="localhost", user="user", passwd="password")

print(mydb)

if(mydb):
    print("Connection Successful")
else:
    print("Connection Unsuccessful")
