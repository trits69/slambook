$("button").click(function (e) {
  e.preventDefault();
});
